export interface Hero {
  id: number;
  name: string;
  team: string;
}
