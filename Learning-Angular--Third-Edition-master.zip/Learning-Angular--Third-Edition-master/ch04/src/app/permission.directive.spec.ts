import { PermissionDirective } from './permission.directive';

describe('PermissionDirective', () => {
  it('should create an instance', () => {
    const directive = new PermissionDirective();
    expect(directive).toBeTruthy();
  });
});
